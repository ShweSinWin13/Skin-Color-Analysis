"""
Train Step-6 SVM on CSV of LAB features (200–500+ labeled faces recommended).

CSV columns (header row required):
  L_mean,a_mean,b_mean,L_std,a_std,b_std,season

Example:
  L_mean,a_mean,b_mean,L_std,a_std,b_std,season
  162.3,138.2,142.1,12.4,4.2,3.8,Spring

Usage:
  python train_season_svm.py --csv path/to/labeled_features.csv --test-size 0.2

Writes models/season_svm.joblib (creates models/ if needed).
"""
import argparse
import csv
import os

import joblib
import numpy as np
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

REQUIRED_COLS = ("L_mean", "a_mean", "b_mean", "L_std", "a_std", "b_std", "season")


def load_xy(csv_path):
    X, y = [], []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError("CSV has no header")
        missing = [c for c in REQUIRED_COLS if c not in reader.fieldnames]
        if missing:
            raise ValueError(f"CSV missing columns: {missing}")
        for row in reader:
            try:
                X.append([
                    float(row["L_mean"]),
                    float(row["a_mean"]),
                    float(row["b_mean"]),
                    float(row["L_std"]),
                    float(row["a_std"]),
                    float(row["b_std"]),
                ])
                y.append(row["season"].strip())
            except (KeyError, ValueError) as e:
                raise ValueError(f"Bad row: {row}") from e
    if len(X) < 10:
        raise ValueError("Need at least ~10 rows for a minimal train/test split; prefer 200+.")
    return np.array(X, dtype=np.float64), np.array(y)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="CSV with LAB stats + season label")
    ap.add_argument("--test-size", type=float, default=0.2, help="Holdout fraction (default 0.2)")
    ap.add_argument("--kernel", default="rbf", choices=("rbf", "linear"))
    ap.add_argument("--C", type=float, default=1.0)
    ap.add_argument("--gamma", default="scale")
    args = ap.parse_args()

    X, y = load_xy(args.csv)
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=args.test_size, random_state=42, stratify=y
        )
    except ValueError:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=args.test_size, random_state=42
        )

    clf = SVC(kernel=args.kernel, C=args.C, gamma=args.gamma)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    print(classification_report(y_test, y_pred))

    out_dir = os.path.join(os.path.dirname(__file__), "models")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "season_svm.joblib")
    joblib.dump(clf, out_path)
    print(f"Saved model to {out_path}")


if __name__ == "__main__":
    main()
