"""
Step 6 — SVM season classification from LAB feature vector.
Place a trained model at models/season_svm.joblib (see train_season_svm.py).
If missing, predict_season_from_features returns None and callers use rule-based fallback.
"""
import logging
import os

import joblib
import numpy as np

# Cached estimator after successful load; None means no usable model.
_classifier = None
# True after we have attempted to load once (success or failure — avoids re-reading disk).
_load_attempted = False

_MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")
MODEL_FILENAME = "season_svm.joblib"
MODEL_PATH = os.path.join(_MODEL_DIR, MODEL_FILENAME)


def load_classifier():
    global _classifier, _load_attempted
    if _classifier is not None:
        return _classifier
    if _load_attempted:
        return None
    _load_attempted = True

    if not os.path.isfile(MODEL_PATH):
        logging.info("No SVM model at %s — using rule-based season fallback", MODEL_PATH)
        return None
    try:
        _classifier = joblib.load(MODEL_PATH)
        logging.info("Loaded SVM season model from %s", MODEL_PATH)
        return _classifier
    except Exception as e:
        logging.error("Failed to load SVM model: %s", e)
        _classifier = None
        return None


def predict_season_from_features(feature_vector):
    """
    feature_vector: sequence of 6 floats
    [L_mean, a_mean, b_mean, L_std, a_std, b_std]
    Returns season string or None if model unavailable.
    """
    model = load_classifier()
    if model is None:
        return None
    X = np.asarray(feature_vector, dtype=np.float64).reshape(1, -1)
    pred = model.predict(X)
    return str(pred[0])
