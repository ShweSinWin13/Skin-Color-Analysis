"""
STEP 2 — Train Dry/Normal/Oily skin texture classifier.

Usage (from backend/):
  python train_texture_model.py
  python train_texture_model.py --csv skin_texture_features.csv --out models/skin_texture_svm_model.pkl
"""
from __future__ import annotations

import argparse
import csv
import logging
import os
import sys

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from skin_texture_features import FEATURE_NAMES

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def load_xy(csv_path: str):
    X, y = [], []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV has no header")
        missing = [c for c in FEATURE_NAMES if c not in reader.fieldnames]
        if missing or "texture" not in reader.fieldnames:
            raise ValueError(f"CSV missing columns: {missing + (['texture'] if 'texture' not in reader.fieldnames else [])}")
        for row in reader:
            X.append([float(row[c]) for c in FEATURE_NAMES])
            y.append(str(row["texture"]).strip().capitalize())
    if len(X) < 6:
        raise ValueError("Need at least ~6 labeled rows to train; add more dataset images.")
    return np.asarray(X, dtype=np.float64), np.asarray(y)


def main() -> int:
    ap = argparse.ArgumentParser(description="Train skin texture SVM/RF classifier")
    ap.add_argument(
        "--csv",
        default=os.path.join(os.path.dirname(__file__), "skin_texture_features.csv"),
    )
    ap.add_argument(
        "--out",
        default=os.path.join(os.path.dirname(__file__), "models", "skin_texture_svm_model.pkl"),
    )
    ap.add_argument("--test-size", type=float, default=0.2)
    ap.add_argument("--model", choices=("svm", "rf"), default="svm")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if not os.path.isfile(args.csv):
        logging.error("CSV not found: %s (run extract_texture_features.py first)", args.csv)
        return 1

    X, y = load_xy(args.csv)
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=args.test_size, random_state=args.seed, stratify=y
        )
    except ValueError:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=args.test_size, random_state=args.seed
        )

    if args.model == "rf":
        clf = RandomForestClassifier(n_estimators=200, random_state=args.seed)
    else:
        clf = SVC(kernel="rbf", C=10.0, gamma="scale", probability=True, random_state=args.seed)

    # Always scale features before the classifier (SVM and RF)
    pipe = Pipeline([("scaler", StandardScaler()), ("clf", clf)])

    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    logging.info("Holdout report:\n%s", classification_report(y_test, pred, zero_division=0))

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    joblib.dump(
        {
            "pipeline": pipe,
            "feature_names": list(FEATURE_NAMES),
            "classes": sorted(set(y.tolist())),
            "model_type": args.model,
        },
        args.out,
    )
    logging.info("Saved model to %s", args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
