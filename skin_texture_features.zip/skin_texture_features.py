"""
Skin texture feature helpers (Dry / Normal / Oily).

Isolated from personal-color seasonal logic. Reuses MediaPipe Face Mesh cheek
landmark indices from skin_lab_pipeline (import only — does not modify that module).

Improvements for dry vs studio-light oily confusion:
- Left/right cheek patches only (avoids nose-bridge specular)
- GLCM on UNBLURRED grayscale (no bilateral / heavy smooth)
- Strict specular mask (L* > 245 or V > 240) excluded from texture metrics
- Laplacian / Sobel gradient std for micro-roughness
"""
from __future__ import annotations

import logging
import os
from typing import List, Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np

from skin_lab_pipeline import LEFT_CHEEK_IDX, RIGHT_CHEEK_IDX

FEATURE_NAMES: Tuple[str, ...] = (
    "glcm_contrast",
    "glcm_dissimilarity",
    "glcm_homogeneity",
    "glcm_energy",
    "glcm_asm",
    "laplacian_std",
    "sobel_std",
    "specular_ratio",
)

# Rule-based thresholds (cheek ROI, unblurred GLCM + strict specular)
# Calibrated so soft studio highlights do not force Oily; roughness drives Dry.
OILY_SPECULAR_RATIO = 0.05
DRY_CONTRAST_MIN = 0.40
DRY_DISSIMILARITY_MIN = 0.30
DRY_HOMOGENEITY_MAX = 0.88
DRY_LAPLACIAN_STD_MIN = 50.0
DRY_SOBEL_STD_MIN = 40.0

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

# Strict specular thresholds (studio soft highlights should rarely exceed these)
SPECULAR_L_THRESH = 245
SPECULAR_V_THRESH = 240


def _load_bgr(image_path: str) -> np.ndarray:
    data = np.fromfile(image_path, dtype=np.uint8)
    if data.size == 0:
        raise ValueError(f"Empty image: {image_path}")
    bgr = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError(f"Could not decode image: {image_path}")
    return bgr


def _hull_mask_from_indices(ih: int, iw: int, landmark, indices, dilate_iter: int = 1) -> np.ndarray:
    mask = np.zeros((ih, iw), dtype=np.uint8)
    pts = []
    for i in indices:
        if i >= len(landmark.landmark):
            continue
        lm = landmark.landmark[i]
        px, py = int(lm.x * iw), int(lm.y * ih)
        if 0 <= px < iw and 0 <= py < ih:
            pts.append([px, py])
    if len(pts) < 3:
        return mask
    hull = cv2.convexHull(np.array(pts, dtype=np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    if dilate_iter > 0:
        k = np.ones((3, 3), np.uint8)
        mask = cv2.dilate(mask, k, iterations=dilate_iter)
    return mask


def _build_specular_mask(image_bgr: np.ndarray) -> np.ndarray:
    """Strict highlight mask from LAB L* and HSV Value."""
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
    L = lab[:, :, 0]
    V = hsv[:, :, 2]
    return ((L > SPECULAR_L_THRESH) | (V > SPECULAR_V_THRESH)).astype(np.uint8) * 255


def _face_mesh_landmarks(image_bgr: np.ndarray):
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    face_mesh = mp.solutions.face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    results = face_mesh.process(image_rgb)
    face_mesh.close()
    if not results.multi_face_landmarks:
        return None
    return results.multi_face_landmarks[0]


def _cheek_masks(ih: int, iw: int, landmark) -> Tuple[np.ndarray, np.ndarray]:
    left = _hull_mask_from_indices(ih, iw, landmark, LEFT_CHEEK_IDX, dilate_iter=1)
    right = _hull_mask_from_indices(ih, iw, landmark, RIGHT_CHEEK_IDX, dilate_iter=1)
    return left, right


def _fallback_cheek_masks(image_bgr: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Face-detection bbox cheek estimates when Face Mesh fails."""
    ih, iw = image_bgr.shape[:2]
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    det = mp.solutions.face_detection.FaceDetection(min_detection_confidence=0.5)
    results = det.process(image_rgb)
    det.close()
    if not results.detections:
        raise ValueError("No face detected for cheek texture ROI")

    bbox = results.detections[0].location_data.relative_bounding_box
    x = max(0, int(bbox.xmin * iw))
    y = max(0, int(bbox.ymin * ih))
    w = max(1, int(bbox.width * iw))
    h = max(1, int(bbox.height * ih))

    left = np.zeros((ih, iw), dtype=np.uint8)
    right = np.zeros((ih, iw), dtype=np.uint8)
    # Mid-face horizontal band; left/right thirds (away from nose center)
    y0, y1 = y + int(0.35 * h), y + int(0.72 * h)
    lx0, lx1 = x + int(0.08 * w), x + int(0.32 * w)
    rx0, rx1 = x + int(0.68 * w), x + int(0.92 * w)
    left[y0:y1, lx0:lx1] = 255
    right[y0:y1, rx0:rx1] = 255
    return left, right


def _crop_masked_gray(
    gray: np.ndarray,
    region_mask: np.ndarray,
    specular_mask: np.ndarray,
    min_side: int = 24,
) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    """
    High-res cheek crop with specular pixels removed from the analysis mask.
    Returns (gray_crop, valid_mask_crop) or None.
    """
    analysis = cv2.bitwise_and(region_mask, cv2.bitwise_not(specular_mask))
    ys, xs = np.where(region_mask > 0)
    if len(xs) < 40:
        return None
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    # Slight pad for context but stay inside image
    pad = 2
    ih, iw = gray.shape[:2]
    x0, y0 = max(0, x0 - pad), max(0, y0 - pad)
    x1, y1 = min(iw, x1 + pad), min(ih, y1 + pad)
    if (x1 - x0) < min_side or (y1 - y0) < min_side:
        return None

    gray_crop = gray[y0:y1, x0:x1].copy()  # UNBLURRED
    valid = analysis[y0:y1, x0:x1] > 0
    if int(valid.sum()) < 50:
        return None

    # Replace specular / non-cheek pixels with local non-specular median so GLCM
    # stays spatially coherent without including highlight texture.
    fill = int(np.median(gray_crop[valid]))
    repaired = gray_crop.copy()
    repaired[~valid] = fill
    return repaired, valid.astype(np.uint8) * 255


def _glcm_props(
    gray_2d: np.ndarray,
    valid_mask: Optional[np.ndarray] = None,
    levels: int = 16,
    distance: int = 1,
) -> Tuple[float, float, float, float, float]:
    """
    GLCM Contrast, Dissimilarity, Homogeneity, Energy, ASM on unblurred grey.
    If valid_mask is provided, only pairs where BOTH pixels are valid are counted.
    """
    if gray_2d.size < 16 or gray_2d.ndim != 2:
        return 0.0, 0.0, 0.0, 0.0, 0.0

    g = np.clip((gray_2d.astype(np.float64) / 255.0) * (levels - 1), 0, levels - 1).astype(np.int32)
    if g.shape[1] <= distance:
        return 0.0, 0.0, 0.0, 0.0, 0.0

    left = g[:, :-distance]
    right = g[:, distance:]
    if valid_mask is not None:
        vm = (valid_mask > 0).astype(np.uint8)
        if vm.shape != g.shape:
            vm = cv2.resize(vm, (g.shape[1], g.shape[0]), interpolation=cv2.INTER_NEAREST)
        pair_ok = (vm[:, :-distance] > 0) & (vm[:, distance:] > 0)
        if int(pair_ok.sum()) < 20:
            return 0.0, 0.0, 0.0, 0.0, 0.0
        li = left[pair_ok]
        ri = right[pair_ok]
    else:
        li = left.ravel()
        ri = right.ravel()

    glcm = np.zeros((levels, levels), dtype=np.float64)
    np.add.at(glcm, (li, ri), 1.0)
    total = glcm.sum()
    if total <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0
    p = glcm / total

    i_idx = np.arange(levels).reshape(-1, 1)
    j_idx = np.arange(levels).reshape(1, -1)
    abs_diff = np.abs(i_idx - j_idx).astype(np.float64)
    diff2 = abs_diff ** 2

    contrast = float((p * diff2).sum())
    dissimilarity = float((p * abs_diff).sum())
    homogeneity = float((p / (1.0 + diff2)).sum())
    asm = float((p ** 2).sum())
    energy = float(np.sqrt(asm))
    return contrast, dissimilarity, homogeneity, energy, asm


def _gradient_stds(gray_2d: np.ndarray, valid_mask: np.ndarray) -> Tuple[float, float]:
    """Std of Laplacian and Sobel magnitude on valid (non-specular) cheek pixels."""
    valid = valid_mask > 0
    if int(valid.sum()) < 30:
        return 0.0, 0.0

    lap = cv2.Laplacian(gray_2d, cv2.CV_64F, ksize=3)
    sx = cv2.Sobel(gray_2d, cv2.CV_64F, 1, 0, ksize=3)
    sy = cv2.Sobel(gray_2d, cv2.CV_64F, 0, 1, ksize=3)
    mag = np.sqrt(sx * sx + sy * sy)

    laplacian_std = float(np.std(lap[valid]))
    sobel_std = float(np.std(mag[valid]))
    return laplacian_std, sobel_std


def _features_from_cheek_crop(gray_crop: np.ndarray, valid_mask: np.ndarray) -> List[float]:
    contrast, dissim, homo, energy, asm = _glcm_props(gray_crop, valid_mask)
    lap_std, sob_std = _gradient_stds(gray_crop, valid_mask)
    return [contrast, dissim, homo, energy, asm, lap_std, sob_std]


def extract_texture_feature_vector(image_path: str) -> List[float]:
    """
    Cheek-focused texture vector:
    [contrast, dissimilarity, homogeneity, energy, asm, laplacian_std, sobel_std, specular_ratio]
    """
    bgr = _load_bgr(image_path)
    ih, iw = bgr.shape[:2]
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)  # no bilateral / no heavy blur
    specular = _build_specular_mask(bgr)

    landmark = _face_mesh_landmarks(bgr)
    if landmark is not None:
        left_mask, right_mask = _cheek_masks(ih, iw, landmark)
    else:
        left_mask, right_mask = _fallback_cheek_masks(bgr)

    cheek_union = cv2.bitwise_or(left_mask, right_mask)
    if int((cheek_union > 0).sum()) < 80:
        raise ValueError(f"Insufficient cheek ROI for texture features: {image_path}")

    # Specular area ratio on cheek regions only (strict threshold) — oiliness signal
    cheek_pixels = cheek_union > 0
    specular_ratio = float(np.mean((specular > 0)[cheek_pixels])) if cheek_pixels.any() else 0.0

    patch_feats: List[List[float]] = []
    for region in (left_mask, right_mask):
        cropped = _crop_masked_gray(gray, region, specular)
        if cropped is None:
            continue
        gray_crop, valid_mask = cropped
        patch_feats.append(_features_from_cheek_crop(gray_crop, valid_mask))

    if not patch_feats:
        raise ValueError(f"Could not extract cheek patches (all specular or too small): {image_path}")

    mean_feats = np.mean(np.asarray(patch_feats, dtype=np.float64), axis=0)
    return [
        float(mean_feats[0]),
        float(mean_feats[1]),
        float(mean_feats[2]),
        float(mean_feats[3]),
        float(mean_feats[4]),
        float(mean_feats[5]),
        float(mean_feats[6]),
        float(specular_ratio),
    ]


def classify_texture_from_features(features: List[float]) -> str:
    """
    Rule-based Dry / Normal / Oily from the 8-D cheek feature vector.
    No ML model or labeled dataset required.

    features =
      [contrast, dissimilarity, homogeneity, energy, asm,
       laplacian_std, sobel_std, specular_ratio]
    """
    if features is None or len(features) < 8:
        return "Normal"

    contrast = float(features[0])
    dissimilarity = float(features[1])
    homogeneity = float(features[2])
    laplacian_std = float(features[5])
    sobel_std = float(features[6])
    specular = float(features[7])

    # 1) Clear cheek shine -> Oily (strict; soft studio glow stays below this)
    if specular > OILY_SPECULAR_RATIO:
        return "Oily"

    # 2) Rough / uneven texture -> Dry
    high_roughness = (
        (contrast >= DRY_CONTRAST_MIN and homogeneity <= DRY_HOMOGENEITY_MAX)
        or (dissimilarity >= DRY_DISSIMILARITY_MIN and homogeneity <= DRY_HOMOGENEITY_MAX)
        or (laplacian_std >= DRY_LAPLACIAN_STD_MIN and contrast >= 0.30)
        or (sobel_std >= DRY_SOBEL_STD_MIN and homogeneity <= 0.90)
    )
    if high_roughness:
        return "Dry"

    # 3) Otherwise moderate -> Normal
    return "Normal"


def classify_texture_from_image(image_path: str) -> str:
    """Extract cheek features then apply heuristic thresholds."""
    return classify_texture_from_features(extract_texture_feature_vector(image_path))


def list_labeled_images(dataset_root: str) -> List[Tuple[str, str]]:
    """
    Expect dataset_root/{dry,normal,oily}/*.{jpg,png,...}
    Returns list of (path, label) with labels capitalized Dry/Normal/Oily.
    """
    label_map = {"dry": "Dry", "normal": "Normal", "oily": "Oily"}
    pairs: List[Tuple[str, str]] = []
    for folder, label in label_map.items():
        folder_path = os.path.join(dataset_root, folder)
        if not os.path.isdir(folder_path):
            logging.warning("Missing dataset folder: %s", folder_path)
            continue
        for name in sorted(os.listdir(folder_path)):
            ext = os.path.splitext(name)[1].lower()
            if ext not in IMAGE_EXTENSIONS:
                continue
            pairs.append((os.path.join(folder_path, name), label))
    return pairs
