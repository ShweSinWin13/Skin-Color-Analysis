"""
Runtime skin texture prediction (Dry / Normal / Oily) — rule-based only.

Uses cheek-focused 8-D features + heuristic thresholds.
Does NOT require a labeled dataset or skin_texture_svm_model.pkl.
Does not touch seasonal personal-color classification.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from skin_texture_features import (
    FEATURE_NAMES,
    classify_texture_from_features,
    extract_texture_feature_vector,
)


def predict_skin_texture(image_path: str) -> Optional[Dict[str, Any]]:
    """
    Returns dict with skin_texture + feature breakdown, or None on hard failure.
    Never raises to callers that want soft-fail integration.
    """
    try:
        features = extract_texture_feature_vector(image_path)
        label = classify_texture_from_features(features)
    except Exception as e:
        logging.warning("Skin texture analysis failed: %s", e)
        return None

    if label not in ("Dry", "Normal", "Oily"):
        label = "Normal"

    return {
        "skin_texture": label,
        "skin_texture_source": "heuristic",
        "skin_texture_features": {
            FEATURE_NAMES[i]: float(features[i]) for i in range(len(FEATURE_NAMES))
        },
    }
