"""
Steps 3–5 (aligned with project spec): MediaPipe landmarks on cheeks + forehead,
noise reduction, mild shadow handling via CLAHE on L*, RGB→LAB, feature vector
[L_mean, a_mean, b_mean, L_std, a_std, b_std].
"""
import cv2
import numpy as np
import logging

# MediaPipe Face Mesh indices (468 model) — cheek / forehead sampling regions
LEFT_CHEEK_IDX = [234, 227, 116, 123, 147, 187, 205, 36, 50, 207]
RIGHT_CHEEK_IDX = [454, 447, 345, 352, 376, 411, 425, 266, 280, 427]
FOREHEAD_IDX = [10, 151, 9, 8, 107, 336, 103, 67, 109, 338]

# Hair / eyes (for legacy UI + PDF) when mesh is available
HAIR_OFFSET_ABOVE_FOREHEAD = 0.06
LEFT_EYE_IDX = 33
RIGHT_EYE_IDX = 263
FOREFHEAD_TOP_IDX = 10


def _landmark_indices_to_mask(ih, iw, landmark, index_lists, dilate_iter=2):
    mask = np.zeros((ih, iw), dtype=np.uint8)
    for indices in index_lists:
        pts = []
        for i in indices:
            if i >= len(landmark.landmark):
                continue
            lm = landmark.landmark[i]
            px, py = int(lm.x * iw), int(lm.y * ih)
            if 0 <= px < iw and 0 <= py < ih:
                pts.append([px, py])
        if len(pts) < 3:
            continue
        pts = np.array(pts, dtype=np.int32)
        hull = cv2.convexHull(pts)
        m = np.zeros((ih, iw), dtype=np.uint8)
        cv2.fillConvexPoly(m, hull, 255)
        mask = cv2.bitwise_or(mask, m)
    if dilate_iter > 0:
        k = np.ones((5, 5), np.uint8)
        mask = cv2.dilate(mask, k, iterations=dilate_iter)
    return mask


def build_skin_mask_from_mesh(ih, iw, face_landmarks):
    return _landmark_indices_to_mask(
        ih, iw, face_landmarks, [LEFT_CHEEK_IDX, RIGHT_CHEEK_IDX, FOREHEAD_IDX]
    )


def denoise_rgb(image_rgb):
    """Step 4 — noise reduction (bilateral filter on BGR)."""
    bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    filtered = cv2.bilateralFilter(bgr, d=7, sigmaColor=75, sigmaSpace=75)
    return cv2.cvtColor(filtered, cv2.COLOR_BGR2RGB)


def lab_from_denoised_rgb(image_rgb):
    """
    Step 4 — RGB → LAB; reduce shadows on L* with CLAHE (common lightweight approach).
    Call after denoise_rgb(). OpenCV LAB: L in [0,255], a,b centered around 128.
    """
    bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    L, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    L2 = clahe.apply(L)
    lab2 = cv2.merge([L2, a, b])
    return lab2


def lab_feature_vector(lab_image, mask):
    """
    Step 5 — mean and std of L, a, b on masked skin region.
    Returns (feature_list length 6, pixel_count).
    """
    m = mask > 0
    if not np.any(m):
        return None, 0
    L, a, b = cv2.split(lab_image)
    Lv, av, bv = L[m].astype(np.float64), a[m].astype(np.float64), b[m].astype(np.float64)
    feats = [
        float(Lv.mean()), float(av.mean()), float(bv.mean()),
        float(Lv.std()), float(av.std()), float(bv.std()),
    ]
    return feats, int(Lv.size)


def mean_rgb_under_mask(image_rgb, mask):
    m = mask > 0
    if not np.any(m):
        return None
    px = image_rgb[m]
    return np.mean(px, axis=0)


def sample_mesh_point_rgb(image_rgb, landmark, idx, ih, iw):
    if idx >= len(landmark.landmark):
        return None
    lm = landmark.landmark[idx]
    px, py = int(lm.x * iw), int(lm.y * ih)
    if 0 <= py < ih and 0 <= px < iw:
        return image_rgb[py, px].astype(np.float64)
    return None


def hair_eye_rgb_from_mesh(image_rgb, landmark, ih, iw):
    """Hair: above forehead landmark; eyes: 33 / 263."""
    hair_rgb, eye_colors = None, []
    if FOREFHEAD_TOP_IDX < len(landmark.landmark):
        lm = landmark.landmark[FOREFHEAD_TOP_IDX]
        hx = int(lm.x * iw)
        hy = int(max(0, (lm.y - HAIR_OFFSET_ABOVE_FOREHEAD) * ih))
        if 0 <= hy < ih and 0 <= hx < iw:
            hair_rgb = image_rgb[hy, hx].astype(np.float64)
    for idx in (LEFT_EYE_IDX, RIGHT_EYE_IDX):
        c = sample_mesh_point_rgb(image_rgb, landmark, idx, ih, iw)
        if c is not None:
            eye_colors.append(c)
    return hair_rgb, eye_colors


def bbox_skin_mask_from_detection(ih, iw, xmin, ymin, w, h):
    """Inner face ellipse / rectangle when only bbox is available (Step 2 fallback)."""
    mask = np.zeros((ih, iw), dtype=np.uint8)
    cx, cy = int(xmin + w / 2), int(ymin + h * 0.45)
    ax, ay = int(w * 0.35), int(h * 0.25)
    cv2.ellipse(mask, (cx, cy), (ax, ay), 0, 0, 360, 255, -1)
    return mask
